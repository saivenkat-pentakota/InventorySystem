package com.example.InventarySystemWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarySystemWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventarySystemWebApplication.class, args);
	}

}
